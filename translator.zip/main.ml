open Translator
open Tree
open Tokenize

(** [main ()] prompts the user for a functionality of the 
    program then starts it.*)
let main () =
  ANSITerminal.(print_string [green]
                  "\n\nWelcome to our 3110 OCaml Translator.\n");
  print_endline "Please enter the option you would like: (eval or trans).\n";
  print_string  "> ";
  match read_line () with
  | exception End_of_file -> ()
  | category -> match category with
    | "eval" ->  ANSITerminal.(print_string [green]
                                 "\n\n Please enter your expression: \n");
      print_endline "Of the format ( 1 + 1 ) or ( 1 - ( 1 * 1 ) )";
      print_string "> ";
      let input_list = Tokenize.separate_parens 
          (Tokenize.tokenize_string (read_line ())) [] in 
      let symbols = ["+";"-";"*";"/"] in 
      let init_stack = Stack.create () in
      Stack.push (Node("",Leaf,Leaf)) init_stack;
      let expression_tree = build_math_tree input_list symbols 
          (Node("",Leaf,Leaf)) (init_stack) (Node("",Leaf,Leaf)) in 
      let final_num = evaluate_tree expression_tree in 
      print_string ("Solution: " ^ string_of_int final_num ^ "\n")
    | "trans" ->  ANSITerminal.(print_string [green]
                                  "\n\n Please enter your expression: \n");
      let final_string =  create_final_string (read_line ()) in 
      print_string ("Translated: \n" ^ final_string ^ "\n")
    | _ -> print_string 
             "Try again. Choose either 'eval' or 'trans'. \n\n";
      exit 0

(* Execute the engine. *)
let () = main ()
