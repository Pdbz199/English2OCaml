type keywords = If of string | Then of string | Else of string

let ifs = ["if"]
let thens = ["then"]
let elses = ["else"; "otherwise"]

let keyword_list = List.rev_append ifs (List.rev_append thens elses)

(** [split_str str] takes in a given string, [str], and returns a
    string list of substrings that were separated by a space character ' '*)
let split_str str = 
  String.split_on_char ' ' str

(** [complete_text lst keyword_list acc] is a list that is formed by
    taking in a list, [lst], and
    iterating through every element in the list until it hits an
    element that exists in a given [keyword_list].  *)
let rec complete_text lst keyword_list acc = 
  match lst with
  | [] -> List.rev acc
  | h::t -> if List.mem h keyword_list 
    then List.rev acc else (complete_text t keyword_list (h::acc))

(** [str_list_conversion lst acc] takes a given string list and
    combines each element into a full string that's separated by a space*)
let rec str_list_conversion lst acc =
  match lst with
  | [] -> acc
  | h::t -> str_list_conversion t (acc ^ " " ^ h) 

(** [find_keywords lst keyword_list acc] is a list of keywords that is formed
    by iterating through every element in a given [lst] and finding
    given keywords from a [keyword_list]. The values for each type
    are created by calling [complete_text] and [str_list_conversion]
    on the list following finding a keyword.*)
let rec find_keywords lst keyword_list acc= 
  match lst with 
  | [] -> acc
  | h::t -> if List.mem h keyword_list then 
      let combined_string = (str_list_conversion (complete_text t keyword_list []) "") in
      (* let () = print_string combined_string in  *)
      if List.mem h ifs then
        find_keywords t keyword_list (If(combined_string)::acc)
      else if List.mem h thens then
        find_keywords t keyword_list (Then(combined_string)::acc)
      else if List.mem h elses then 
        find_keywords t keyword_list (Else(combined_string)::acc)
      else []
    else  find_keywords t keyword_list acc

(** [final_string lst acc] is a string that is formed from a given
    keywords list, [lst], and concatenates each string associated
    with that type for each element.*)
let rec final_string lst acc =
  match lst with
  | [] -> acc
  | h::t -> match h with
    | If(s) -> final_string t ("if" ^ s ^ " \n" ^ acc)
    | Then(s) -> final_string t ("then" ^ s ^ " \n" ^ acc)
    | Else(s) -> final_string t ("else" ^ s ^ " \n" ^acc)

(** [create_final_string str] is a string that takes in a given string
    input, [str] and re-creates the string with separated keywords.*)
let create_final_string str = 
  final_string (find_keywords (split_str str) keyword_list []) ""